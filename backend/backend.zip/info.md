# Enunciado Frontend

## Hola soy David y soy el responsable de backend-A